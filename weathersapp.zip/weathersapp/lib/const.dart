import 'package:weather/weather.dart';

const OpenWeather_API_Keys = "2f268af904bf9af42a99b543784ae42d";