import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:weather/weather.dart';
import 'package:weathersapp/const.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  final WeatherFactory wf=WeatherFactory(OpenWeather_API_Keys);
  Weather? weather;

  @override
  void initState() {
    super.initState();
    wf.currentWeatherByCityName("Karachi").then((w) => null);
    setState(() {
      weather = weather;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(body:buildUI(),);
  }
  Widget buildUI(){
    if (weather==null) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }
    return SizedBox(
      width: MediaQuery.sizeOf(context).width,
      height: MediaQuery.sizeOf(context).height,
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          locationheader(),
          SizedBox(
            height: MediaQuery.sizeOf(context).height *0.08,
          ),
          dateTimeInfo(),
           SizedBox(
            height: MediaQuery.sizeOf(context).height *0.05,
          ),
          weatherIcon(),
          SizedBox(
            height: MediaQuery.sizeOf(context).height *0.02,
            ),
            currentTemp(),
            SizedBox(
            height: MediaQuery.sizeOf(context).height *0.02,
            ),
            extraInfo(),
        ],
        ),
        );
  }
  Widget locationheader(){
    return Text(weather?.areaName??"",
    style: const TextStyle(
      fontSize: 20,
      fontWeight: FontWeight.w500,
    ));
  }
  Widget dateTimeInfo(){
    DateTime now = weather!.date!;
    return Column(
      children: [
        Text(DateFormat("h:mmam").format(now),
        style:const TextStyle(
          fontSize: 35,
        ),
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
           mainAxisSize: MainAxisSize.max,
           mainAxisAlignment: MainAxisAlignment.center,
           crossAxisAlignment: CrossAxisAlignment.center,
          children: [
          Text(
            DateFormat("EEEE").format(now),
            style:const TextStyle(
            fontWeight: FontWeight.w700,
        ),
        ),
        Text(
            "${DateFormat("d,m,y").format(now)}",
            style:const TextStyle(
            fontWeight: FontWeight.w700,
        ),
        ),
          ],
        )
        ],
    );
  }
  Widget weatherIcon(){
    return Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(decoration: BoxDecoration(image: DecorationImage(image: NetworkImage("file:///E:/Furqan%20flutter/download%20(6).png ${weather?.weatherIcon}"))),)
      ],
    );
  }
  Widget currentTemp() {
    return Text("${weather?.temperature?.celsius.toStringAsFixed(0)} c",
    style: const TextStyle(
      color: Colors.black,
      fontSize: 90,
      fontWeight: FontWeight.w500,
    ),
    );
  }
  Widget extraInfo(){
    return Container(
      height: MediaQuery.sizeOf(context).height *0.15,
      width: MediaQuery.sizeOf(context).width *0.80,
      decoration: BoxDecoration(color: Colors.deepPurpleAccent,
      borderRadius:BorderRadius.circular(20,
      ),
      ),
      padding: const EdgeInsets.all(8.0
      ),
      child: Column(
       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
       crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
           mainAxisSize: MainAxisSize.max,
           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
           crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                "Max:${weather?.tempMax?.celsius?.toStringAsFixed(0)} c",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                ),
                ),
                Text(
                "Min:${weather?.tempMin?.celsius?.toStringAsFixed(0)} c",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                ),
                ),
            ],
          ),
          Row(
           mainAxisSize: MainAxisSize.max,
           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
           crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                "Wind:${weather?.windSpeed?.toStringAsFixed(0)} c",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                ),
                ),
                Text(
                "Humidity:${weather?.humidity?.celsius?.toStringAsFixed(0)} c",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}